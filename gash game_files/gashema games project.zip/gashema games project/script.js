// Initialize the puzzle container and tiles
const tiles = document.querySelectorAll('.tile');
const emptyTile = document.getElementById('empty-tile');
const shuffleBtn = document.getElementById('shuffle-btn');
const moveCountElement = document.getElementById('move-count');
const timerElement = document.getElementById('timer');
const winMessage = document.getElementById('win-message');

// Convert NodeList to Array
let tileArray = Array.from(tiles);
let moveCount = 0;
let timer = null;
let seconds = 0;

// Set up the initial tile positions
let positions = [
    { row: 0, col: 0 }, { row: 0, col: 1 }, { row: 0, col: 2 }, { row: 0, col: 3 },
    { row: 1, col: 0 }, { row: 1, col: 1 }, { row: 1, col: 2 }, { row: 1, col: 3 },
    { row: 2, col: 0 }, { row: 2, col: 1 }, { row: 2, col: 2 }, { row: 2, col: 3 },
    { row: 3, col: 0 }, { row: 3, col: 1 }, { row: 3, col: 2 }, { row: 3, col: 3 }
];

// Set initial position of tiles
function initPositions() {
    tileArray.forEach((tile, index) => {
        const position = positions[index];
        tile.style.transform = `translate(${position.col * 105}px, ${position.row * 105}px)`;
    });
}

// Shuffle the tiles
function shuffleTiles() {
    moveCount = 0;
    moveCountElement.textContent = moveCount;
    seconds = 0;
    updateTimer();
    winMessage.textContent = '';

    // Shuffle tiles randomly except the empty one
    for (let i = tileArray.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [positions[i], positions[j]] = [positions[j], positions[i]];
    }
    initPositions();

    // Reset and start the timer
    clearInterval(timer);
    timer = setInterval(updateTimer, 1000);
}

// Check if a tile is adjacent to the empty tile
function isAdjacent(tileIndex) {
    const emptyPosition = positions[15];
    const tilePosition = positions[tileIndex];

    const rowDiff = Math.abs(tilePosition.row - emptyPosition.row);
    const colDiff = Math.abs(tilePosition.col - emptyPosition.col);

    return (rowDiff === 1 && colDiff === 0) || (rowDiff === 0 && colDiff === 1);
}

// Move the tile if adjacent to the empty space
function moveTile(tile, index) {
    if (isAdjacent(index)) {
        [positions[15], positions[index]] = [positions[index], positions[15]];
        initPositions();
        moveCount++;
        moveCountElement.textContent = moveCount;

        // Check if the puzzle is solved
        if (isSolved()) {
            clearInterval(timer);
            winMessage.textContent = 'Congratulations! You solved the puzzle!';
        }
    }
}

// Add click event to each tile to move it
tileArray.forEach((tile, index) => {
    tile.addEventListener('click', () => moveTile(tile, index));
});

// Shuffle button functionality
shuffleBtn.addEventListener('click', shuffleTiles);

// Initialize the puzzle position
initPositions();

// Timer function
function updateTimer() {
    seconds++;
    const minutes = Math.floor(seconds / 60);
    const displaySeconds = seconds % 60;
    timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${displaySeconds.toString().padStart(2, '0')}`;
}

// Check if the puzzle is solved
function isSolved() {
    for (let i = 0; i < 15; i++) {
        if (positions[i].row !== Math.floor(i / 4) || positions[i].col !== i % 4) {
            return false;
        }
    }
    return true;
}
